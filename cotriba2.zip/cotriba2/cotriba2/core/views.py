from django.shortcuts import render
from django.http import HttpResponse

# CRIE AS VIEWS AQUI

# VIEW DA HOME - PÁGINA INICIAL DO SITE
def home(request):
    return render(request, 'base.html')