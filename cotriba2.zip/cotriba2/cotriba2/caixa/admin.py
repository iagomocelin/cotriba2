from django.contrib import admin
from django.urls import path, include
from .models import Produto, Parametro, NotaFiscal, ItemNF
from .forms import ImportNF
from django.shortcuts import render, redirect
from django.template import Context, Template
import xml.etree.ElementTree as ET
import os
import io
from django.db import transaction
from django.http import HttpResponse


#from .views import (
#    importnf,
#)

# REGISTRE OS MODELS AQUI PARA PODER ADMINISTRÁ-LOS PELO DJANGO

# MODEL PRODUTO
class AdminProduto(admin.ModelAdmin):
    list_display = ('nome', 'ncm',)
    list_filter = ('ncm',)
    search_fields = ['ncm', 'nome',]

admin.site.register(Produto, AdminProduto)

# PRODUTOINLINE PERMITE ADICIONAR PRODUTOS A UMA NOTA FISCAL A PARTIR DO ADMIN DE NOTA FISCAL
class ProdutoInline(admin.TabularInline):
    model = ItemNF

class AdminNotaFiscal(admin.ModelAdmin):
    list_display = ('identificador',)
    search_fields = ['identificador',]
    inlines = [ProdutoInline] # ADICIONAR PRODUTOS À NOTA DIRETAMENTE PELO ADMIN DURANTE A CRIAÇÃO

    change_list_template = "caixa_changelist.html" # ADICIONA O BOTÃO "IMPORTAR eNF" NO ADMIN DE NOTA FISCAL
    
    def get_urls(self):
        urls = super().get_urls()
        my_urls = [
            path('import-nf/', self.importnf),
        ]
        return my_urls + urls
    
    # FUNÇÃO DE IMPORTAÇÃO DA NOTA FISCAL
    def importnf(self, request): 
        nr_importacoes = 0 # VARIÁVEL NÚMERO DE VEZES QUE NOTAS FORAM IMPORTADAS
        context = {}       # DECLARANDO DICIONÁRIO
        produto = []       # DECLARANDO A LISTA DE PRODUTOS
        ncm = []           # DECLARANDO A LISTA DE NCMs
        
        if request.method == "POST":
            file = request.FILES["nf_file"] # MANDA SELECIONAR UM ARQUIVO DO PC
            tree = ET.parse(file)           # SEPARA O XML
            root = tree.getroot()           # ACHA A RAIZ DO XML
            nr_importacoes += 1             # AUMENTA O NÚMERO DE IMPORTAÇÕES
        
            with transaction.atomic():
                id = root.find("NFe").find("infNFe").attrib["Id"] # ACHA O ID DA NOTA
                fornecedor = root.find("NFe").find("infNFe").find("emit").find("xNome").text # ACHA O FORNECEDOR
                nf, created = NotaFiscal.objects.get_or_create(identificador = id) # DIZ PRA CRIAR UMA NOTA FISCAL NO BANCO 
                
                for prod in root.iter('prod'):              # PRA CADA TAG PROD (PRODUTO) NO XML
                    produto_xProd = prod.find('xProd').text # ACHA O NOME DO PRODUTO
                    produto_NCM = prod.find('NCM').text     # ACHA O NCM DO PRODUTO
                    
                    produto.append(produto_xProd) # ADICIONA O PRODUTO MAIS RECENTE NA LISTA DE PRODUTOS A SEREM EXIBIDOS
                    ncm.append(produto_NCM)       # ADICIONA O NCM NA LISTA DE NCMs A SEREM EXIBIDOS
                
                    
                      
                    context = {                                     # INSERE AS VARIÁVEIS NO DICIONÁRIO PRA PODER CHAMÁ-LAS NO TEMPLATE HTML
                        'fornecedor': fornecedor,               
                        'nota': id,
                        'produtos': produto,
                        'ncm': ncm,
                        'importacoes': nr_importacoes,
                        'produtosbanco': Produto.objects.all()[:5], # CHAMA TODOS OS PRODUTOS PREVIAMENTE CADASTRADOS NO BANCO
                    }
                    
                    
                    #maxscore = 0
                    #for prodc in Produto.objects.filter(ncm=produto_NCM):
                        #if (Parametro.objects.filter(funcao=1)):
                        #    jk = JaroWinkler()
                        #    score = jk.similarity(produto_xProd, prodc.nome)
                        #    if (maxscore < score):
                        #        maxscore = score
                        #        maxprod = prodc      
                        #if (maxscore>=1):
                        #    created = ItemNF.objects.get_or_create(
                        #        cod_produto = maxprod,
                        #     cod_nf = nf)
                        #nr_importacoes += 1
                        #self.message_user(request, "Importações realizadas: {}".format(nr_importacoes))
                        #self.message_user(request, "Score: {}".format(maxscore))
                
                
                template_name = 'products.html'
                return render(request, template_name, context) # ENCAMINHA PRO TEMPLATE PRODUCTS.HTML COM OS DADOS DO DICIONÁRIO
                
        
        form = ImportNF()
        payload = {"form": form}
        template_name='nf_form.html'
        return render(request, template_name, payload)

admin.site.register(NotaFiscal, AdminNotaFiscal)

# LISTA PRODUTOS POR NOTA FISCAL (MAS AINDA NÃO SEI POR QUE ELE EXISTE??? N/N???)
class AdminItemNF(admin.ModelAdmin):
    list_display = ('cod_nf', 'cod_produto')
    search_fields = [ 'cod_nf',]

admin.site.register(ItemNF, AdminItemNF)

admin.site.site_header = 'COTRIBÁ - ADMINISTRAÇÃO'   # HEADER NO ADMIN                 
admin.site.index_title = 'Admin'                     # HTML TITLE DA PÁGINA INICIAL DO ADMIN
admin.site.site_title = 'COTRIBÁ'                    # TÍTULO DE TUDO ADICIONADO AO FINAL DO TITLE DE CADA PÁGINA