from django.contrib import admin
from django.urls import path, include
from .models import Produto, Parametro, NotaFiscal, ItemNF
from .forms import ImportNF, Substituicao
from django.shortcuts import render, redirect
from django.template import Context, Template
import xml.etree.ElementTree as ET
import os
import io
from django.db import transaction
from django.http import HttpResponse
from .views import importnf

# REGISTRE OS MODELS AQUI PARA PODER ADMINISTRÁ-LOS PELO DJANGO

# MODEL PRODUTO
class AdminProduto(admin.ModelAdmin):
    list_display = ('nome', 'ncm',)
    list_filter = ('ncm',)
    search_fields = ['ncm', 'nome',]

admin.site.register(Produto, AdminProduto)

# PRODUTOINLINE PERMITE ADICIONAR PRODUTOS A UMA NOTA FISCAL A PARTIR DO ADMIN DE NOTA FISCAL
class ProdutoInline(admin.TabularInline):
    model = ItemNF

class AdminNotaFiscal(admin.ModelAdmin):
    list_display = ('identificador',)
    search_fields = ['identificador',]
    inlines = [ProdutoInline] # ADICIONAR PRODUTOS À NOTA DIRETAMENTE PELO ADMIN DURANTE A CRIAÇÃO

    change_list_template = "caixa_changelist.html" # ADICIONA O BOTÃO "IMPORTAR eNF" NO ADMIN DE NOTA FISCAL
    
    
    
        
        
       
        
        

admin.site.register(NotaFiscal, AdminNotaFiscal)

# LISTA PRODUTOS POR NOTA FISCAL (MAS AINDA NÃO SEI POR QUE ELE EXISTE??? N/N???)
class AdminItemNF(admin.ModelAdmin):
    list_display = ('cod_nf', 'cod_produto')
    search_fields = [ 'cod_nf',]

admin.site.register(ItemNF, AdminItemNF)

admin.site.site_header = 'COTRIBÁ - ADMINISTRAÇÃO'   # HEADER NO ADMIN                 
admin.site.index_title = 'Admin'                     # HTML TITLE DA PÁGINA INICIAL DO ADMIN
admin.site.site_title = 'COTRIBÁ'                    # TÍTULO DE TUDO ADICIONADO AO FINAL DO TITLE DE CADA PÁGINA