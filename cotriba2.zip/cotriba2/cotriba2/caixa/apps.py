from django.apps import AppConfig


class CaixaConfig(AppConfig):
    name = 'caixa'
