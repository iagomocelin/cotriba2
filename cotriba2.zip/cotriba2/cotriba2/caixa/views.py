from django.shortcuts import render
from .forms import ImportNF
# Create your views here.

#def importnf(request):
#    nr_importações == 0
#    if request_method == "POST":
#        file = request.FILES["nf_file"]
#        tree = ET.parse(file)
#        root = tree.getroot()
#        nr_importações += 1
#    form = ImportNF()
#    payload = {"form": form}
#    template_name='nf_form.html'
#    return render(request, template_name, payload)

#def listproducts(request, slug):
#    nf = get_object_or_404(NotaFiscal, slug=slug)
#    context={}
#    if request.method == 'POST':
#        form = ContactCourse(request.POST)
#        if form.is_valid():
#            context['is_valid'] = True
#            form.send_mail(course)
#            form = ContactCourse()       
#    else:
#        form = ContactCourse()
#    context['form'] = form
#    context['course'] = course
#    template_name = 'courses/details.html'
#    return render(request, template_name, context)