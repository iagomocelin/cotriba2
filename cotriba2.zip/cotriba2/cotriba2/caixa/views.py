from django.contrib import admin
from django.urls import path, include
from .models import Produto, Parametro, NotaFiscal, ItemNF
from .forms import ImportNF, Substituicao
from django.shortcuts import render, redirect
from django.template import Context, Template
import xml.etree.ElementTree as ET
import os
import io
from django.db import transaction
from django.http import HttpResponse


# FUNÇÃO DE IMPORTAÇÃO DA NOTA FISCAL
def importnf(request): 
    
    # VARIÁVEL NÚMERO DE VEZES QUE NOTAS FORAM IMPORTADAS
    context = {}       # DECLARANDO DICIONÁRIO
    produto = []       # DECLARANDO A LISTA DE PRODUTOS
    ncm = []           # DECLARANDO A LISTA DE NCMs
    
    if request.method == "POST":
        
        file = request.FILES["nf_file"] # MANDA SELECIONAR UM ARQUIVO DO PC
        tree = ET.parse(file)           # SEPARA O XML
        root = tree.getroot()           # ACHA A RAIZ DO XML
                    # AUMENTA O NÚMERO DE IMPORTAÇÕES
        form = Substituicao(request.POST)
        with transaction.atomic():
            id = root.find("NFe").find("infNFe").attrib["Id"] # ACHA O ID DA NOTA
            fornecedor = root.find("NFe").find("infNFe").find("emit").find("xNome").text # ACHA O FORNECEDOR
            nf, created = NotaFiscal.objects.get_or_create(identificador = id) # DIZ PRA CRIAR UMA NOTA FISCAL NO BANCO 
            
            for prod in root.iter('prod'):              # PRA CADA TAG PROD (PRODUTO) NO XML
                produto_xProd = prod.find('xProd').text # ACHA O NOME DO PRODUTO
                produto_NCM = prod.find('NCM').text     # ACHA O NCM DO PRODUTO
                
                produto.append(produto_xProd) # ADICIONA O PRODUTO MAIS RECENTE NA LISTA DE PRODUTOS A SEREM EXIBIDOS
                ncm.append(produto_NCM)       # ADICIONA O NCM NA LISTA DE NCMs A SEREM EXIBIDOS
            
                
                substituto = form.substituir('substituto')
                context = {                                     # INSERE AS VARIÁVEIS NO DICIONÁRIO PRA PODER CHAMÁ-LAS NO TEMPLATE HTML
                    'fornecedor': fornecedor,               
                    'nota': id,
                    'produtos': produto,
                    'ncm': ncm,
                    #'importacoes': nr_importacoes,
                    'substituto': substituto
                    #'produtosbanco': Produto.objects.all()[:5], # CHAMA TODOS OS PRODUTOS PREVIAMENTE CADASTRADOS NO BANCO
                }
                request.session['context'] = query
                #maxscore = 0
                #for prodc in Produto.objects.all():
                    #if (Parametro.objects.filter(funcao=1)):
                    #    jk = JaroWinkler()
                    #    score = jk.similarity(produto_xProd, prodc.nome)
                    #    if (maxscore < score):
                    #        maxscore = score
                    #        maxprod = prodc      
                    #if (maxscore>=1):
                    #created = ItemNF.objects.get_or_create( cod_produto = substituto, cod_nf = nf)
                    #nr_importacoes += 1
                
                
                
                  
            form = Substituicao()
            context['form'] = form
            template_name = 'products.html'
            return render(request, template_name, context) # ENCAMINHA PRO TEMPLATE PRODUCTS.HTML COM OS DADOS DO DICIONÁRIO
            
    
    form = ImportNF()
    payload = {"form": form}
    template_name='nf_form.html'
    return render(request, template_name, payload)

def itemnf(request):
    context = request.session.get('context')
    return render(request, 'itemnf.html', context)