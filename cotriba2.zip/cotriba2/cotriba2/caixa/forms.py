from django import forms
from django.conf import settings

class ImportNF(forms.Form):
    nf_file = forms.FileField()