from django import forms
from django.conf import settings
from .models import Produto
class ImportNF(forms.Form):
    nf_file = forms.FileField(label='Nota Fiscal')

class Substituicao(forms.Form):
    substituto = forms.IntegerField(label='Substituto', widget=forms.Select(
        choices=Produto.objects.all()[:5].values_list('id', 'nome')
    ))

    def substituir(self, substituto):
        seila = '%s' % substituto
        context = {
            'seila': seila
        }
