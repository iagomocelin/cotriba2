from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator # dita os valores mínimos e máximos dos limiares pro usuário inserir

# CRIAÇÃO DE MODLES - OBJETOS - ENTIDADES
class Produto(models.Model):
    nome = models.CharField(max_length = 300, blank = False)
    ncm = models.PositiveIntegerField(verbose_name = 'NCM')

    def __str__(self):
        return self.nome + ' - ' + str(self.ncm)

class Parametro(models.Model):
    limiarsemi = models.DecimalField(
        verbose_name = 'Limiar Semi-Automático', validators = [MaxValueValidator(1), MinValueValidator(0)], decimal_places= 2, max_digits=3, null = False) # abaixo desse é excluído automaticamente e acima desse mas menor que o auto, vai para avaliação
    limiarautomatico = models.DecimalField(
        verbose_name = 'Limiar Automático', validators = [MaxValueValidator(1), MinValueValidator(0)], decimal_places= 2, max_digits=3, null = False ) # acima desse é adicionado automaticamente
    FUNCAO_CHOICES = (
        (1, 'JarotWinkler'), # opções de função de similaridade que o usuário pode escolher
        (2, 'Levenshtein'),
    )
    funcao = models.IntegerField(choices=FUNCAO_CHOICES, verbose_name = "Função de Similaridade") # atributo que escolhe as funções

    def __str__(self):
        return str(self.limiarautomatico) + ' - ' + str(self.limiarsemi)

    class Meta:
        verbose_name = 'Parâmetro'
        verbose_name_plural = 'Parâmetros'
        ordering = ['limiarsemi' , 'limiarautomatico',]

class NotaFiscal(models.Model):
    identificador = models.CharField(max_length = 100, blank = True, null = True) # valor único de cada nota

    def __str__(self):
        return str(self.identificador)

    class Meta:
        verbose_name = 'Nota Fiscal'
        verbose_name_plural = 'Notas Fiscais'

class ItemNF (models.Model): # diz qual produto pertence a qual nota /// não sei por que existe direito???
    cod_nf = models.ForeignKey(NotaFiscal, related_name = 'codigo', verbose_name = 'ID da eNF', on_delete = models.PROTECT) 
    cod_produto = models.ForeignKey(Produto, verbose_name = 'produto', on_delete = models.PROTECT)

    def __str__(self):
        return str(self.cod_nf)

    class Meta:
        verbose_name = 'Itens da Nota Fiscal'
        verbose_name_plural = 'Itens das Notas Fiscais'
